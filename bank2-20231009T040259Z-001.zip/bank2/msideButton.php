<form class="form-inline my-2 my-lg-0">
       	<button class="btn btn-outline-primary">Welecome Manager</button>
        <a href="logout.php" data-toggle="tooltip" title="Logout" class="btn btn-outline-danger mx-1" ><i class="fa fa-sign-out fa-fw"></i></a>    
</form>